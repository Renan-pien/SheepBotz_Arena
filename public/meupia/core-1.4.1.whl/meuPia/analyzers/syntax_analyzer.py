from typing import Dict, List, Tuple

from ..utils.builtins import TIPOS_CONTEXTUAIS, TIPOS_ELEMENTO
from ..utils.erros import ErroCompilacao, descrever_token, posicao
from ..utils.token_enum import TokenEnum

class SyntacticError(ErroCompilacao):
  etapa = 'sintático'

class Parser:
  def __init__(self, lexemePairs: List[Dict[str, str]]):
    self.lexeme_pairs = lexemePairs
    self.pos = 0
    self.profundidade_bloco = 0 # > 0 dentro de se/senao/enquanto/para
    self.atribuicoes = [] # (alvo, inicio, fim) de cada 'nome <- expressao' com alvo sem '.' nem '[...]'

  def current_token(self) -> str:
    if self.pos < len(self.lexeme_pairs):
      return self.lexeme_pairs[self.pos]['token']
    
    return TokenEnum.END_OF_FILE.name
  
  def current_lexeme(self) -> str:
    if self.pos < len(self.lexeme_pairs):
      return self.lexeme_pairs[self.pos]['lexeme']
    
    return ' '
  
  def erro(self, descricao: str) -> SyntacticError:
    linha, coluna = posicao(self.lexeme_pairs, self.pos)
    return SyntacticError(descricao, linha, coluna)

  def descrever_atual(self) -> str:
    if self.pos >= len(self.lexeme_pairs):
      return descrever_token(TokenEnum.END_OF_FILE)
    return f'"{self.current_lexeme()}"'

  def peek_next_token(self) -> str:
    if self.pos + 1 < len(self.lexeme_pairs):
      return self.lexeme_pairs[self.pos + 1]['token']
    return ''

  def expect_token(self, expected: TokenEnum):
    if self.current_token() == expected.name:
      self.pos += 1
      return
    
    raise self.erro(f'esperado {descrever_token(expected)}, encontrado {self.descrever_atual()}')
  
  def check_token(self, expected: TokenEnum) -> bool:
    return self.current_token() == expected.name
  
  def is_equal_sign(self) -> bool:
    # '=' e tokenizado como ATR; dentro de expressoes significa comparacao
    return self.check_token(TokenEnum.ATR) and self.current_lexeme() == '='

  def is_chamada_fila_prioridade(self) -> bool:
    # 'filaPrioridade' e tipo para o lexer; seguido de '(' e a funcao nativa que cria a fila
    return self.check_token(TokenEnum.TIPO) and self.current_lexeme().lower() == 'filaprioridade' \
      and self.peek_next_token() == TokenEnum.PARAB.name

  def check_token_any(self, expected: List[TokenEnum]) -> bool:
    return any(self.current_token() == t.name for t in expected)

  def parse(self):
    self.expect_token(TokenEnum.ALGORITMO)
    self.expect_token(TokenEnum.STRING)
    
    # Optional Plugin Imports
    while self.check_token(TokenEnum.USAR):
        self.expect_token(TokenEnum.USAR)
        self.expect_token(TokenEnum.STRING)

    if self.check_token(TokenEnum.VAR):
      self.grammar_variable_block()

    while self.check_token_any([TokenEnum.FUNCAO, TokenEnum.VAR, TokenEnum.CLASSE]):
      if self.check_token(TokenEnum.FUNCAO):
          self.grammar_function_declaration()
      elif self.check_token(TokenEnum.VAR):
          self.grammar_variable_block()
      elif self.check_token(TokenEnum.CLASSE):
          self.grammar_class_declaration()

    self.expect_token(TokenEnum.INICIO)

    while not self.check_token_any([TokenEnum.FIMALGORITMO, TokenEnum.END_OF_FILE]):
      self.statement()

    self.expect_token(TokenEnum.FIMALGORITMO)

    if self.pos < len(self.lexeme_pairs):
      raise self.erro(f'código inesperado depois de "fim_algoritmo": {self.descrever_atual()}')

  def statement(self):
    if self.check_token(TokenEnum.ID):
      self.grammar_id_statement()
    elif self.check_token(TokenEnum.ESCREVA):
      self.grammar_command_escreva()
    elif self.check_token(TokenEnum.LEIA):
      self.grammar_command_leia()
    elif self.check_token(TokenEnum.SE):
      self.grammar_command_se()
    elif self.check_token(TokenEnum.ENQUANTO):
      self.grammar_command_enquanto()
    elif self.check_token(TokenEnum.PARA):
      self.grammar_command_para()
    elif self.check_token(TokenEnum.RETORNE):
      self.grammar_command_retorne()
    elif self.check_token(TokenEnum.CONTINUE):
      self.expect_token(TokenEnum.CONTINUE)
    elif self.check_token(TokenEnum.INTERROMPA):
      self.expect_token(TokenEnum.INTERROMPA)
    elif self.check_token(TokenEnum.VAR):
      if self.profundidade_bloco > 0:
        raise self.erro('declare variáveis com var fora de blocos se, enquanto e para')
      self.grammar_local_declaration()
    else:
      raise self.erro(f'comando inesperado: {self.descrever_atual()}')

  def block_statements(self, fim: List[TokenEnum]):
    # Corpo de se/senao/enquanto/para: comandos ate um dos tokens de fim
    self.profundidade_bloco += 1
    while not self.check_token_any(fim):
      self.statement()
    self.profundidade_bloco -= 1

  def is_declaration_line(self) -> bool:
    # Uma linha de declaracao comeca com 'nome,' ou 'nome:'; nenhum comando comeca assim
    return self.check_token(TokenEnum.ID) and self.peek_next_token() in (TokenEnum.COMMA.name, TokenEnum.COLON.name)

  @staticmethod
  def ler_declaracao_local(lexeme_pairs: List[Dict[str, str]], pos: int) -> Tuple[List[dict], int]:
    """Le o 'var' local que comeca em 'pos' usando a propria gramatica.

    Retorna as linhas (nomes com posicao, tipo e intervalo [inicio, fim) da expressao de valor, ou None)
    e a posicao logo depois da declaracao. Usado pelo semantico e pelo gerador.
    """
    parser = Parser(lexeme_pairs)
    parser.pos = pos
    linhas = parser.grammar_local_declaration()
    return linhas, parser.pos

  @staticmethod
  def ler_bloco_var(lexeme_pairs: List[Dict[str, str]], pos: int) -> Tuple[List[dict], int]:
    """Le o bloco 'var' global que comeca em 'pos'; retorna as linhas e a posicao logo depois do bloco."""
    parser = Parser(lexeme_pairs)
    parser.pos = pos
    linhas = parser.grammar_variable_block()
    return linhas, parser.pos

  @staticmethod
  def usa_colecoes_tipadas(lexeme_pairs: List[Dict[str, str]]) -> bool:
    """Indica se alguma declaracao usa 'vetor[' ou 'lista de' na posicao de tipo."""
    for i in range(1, len(lexeme_pairs) - 1):
      if lexeme_pairs[i - 1]['token'] != TokenEnum.COLON.name or lexeme_pairs[i]['token'] != TokenEnum.ID.name:
        continue
      seguinte = lexeme_pairs[i + 1]['token']
      if (lexeme_pairs[i]['lexeme'] == 'vetor' and seguinte == TokenEnum.COLCHETEA.name) or \
         (lexeme_pairs[i]['lexeme'] == 'lista' and seguinte == TokenEnum.DE.name):
        return True
    return False

  @staticmethod
  def ler_atribuicoes(lexeme_pairs: List[Dict[str, str]]) -> List[Tuple[int, int, int]]:
    """Retorna (alvo, inicio, fim) de cada comando 'nome <- expressao' do programa, com a expressao em [inicio, fim)."""
    parser = Parser(lexeme_pairs)
    parser.parse()
    return parser.atribuicoes

  def grammar_local_declaration(self) -> List[dict]:
    self.expect_token(TokenEnum.VAR)
    linhas = [self.grammar_declaration_line(permite_valor=True)]
    while self.is_declaration_line():
      linhas.append(self.grammar_declaration_line(permite_valor=True))
    return linhas

  def grammar_id_statement(self):
    alvo = self.pos
    self.expect_token(TokenEnum.ID)

    while self.check_token(TokenEnum.PONTO):
      self.expect_token(TokenEnum.PONTO)
      self.expect_token(TokenEnum.ID)

    while self.check_token(TokenEnum.COLCHETEA):
      self.expect_token(TokenEnum.COLCHETEA)
      self.grammar_expression()
      self.expect_token(TokenEnum.COLCHETEF)
      
    if self.check_token(TokenEnum.ATR):
      nome_simples = self.pos == alvo + 1
      self.expect_token(TokenEnum.ATR)
      inicio = self.pos
      self.grammar_expression()
      if nome_simples:
        self.atribuicoes.append((alvo, inicio, self.pos))

    elif self.check_token(TokenEnum.PARAB):
      self.expect_token(TokenEnum.PARAB)
      if not self.check_token(TokenEnum.PARFE):
          self.grammar_expression()
          while self.check_token(TokenEnum.COMMA):
              self.expect_token(TokenEnum.COMMA)
              self.grammar_expression()
      self.expect_token(TokenEnum.PARFE)
    else:
      raise self.erro(f'depois de um nome é preciso "<-" para atribuir ou "(" para chamar, encontrado {self.descrever_atual()}')

  # ----------------
  # Gramáticas
  # ----------------

  def grammar_variable_block(self) -> List[dict]:
    self.expect_token(TokenEnum.VAR)

    linhas = []
    while self.check_token(TokenEnum.ID):
      linhas.append(self.grammar_declaration_line(permite_valor=False))
    return linhas

  def grammar_declaration_line(self, permite_valor: bool) -> dict:
    # nome1, nome2: tipo [<- expressao]  (valor so com um nome e so em declaracoes locais)
    nomes = [(self.current_lexeme(), self.pos)]
    self.expect_token(TokenEnum.ID)

    while self.check_token(TokenEnum.COMMA):
      self.expect_token(TokenEnum.COMMA)
      nomes.append((self.current_lexeme(), self.pos))
      self.expect_token(TokenEnum.ID)

    self.expect_token(TokenEnum.COLON)
    linha = {'nomes': nomes, 'expressao': None}
    linha.update(self.grammar_tipo())
    if permite_valor and self.check_token(TokenEnum.ATR):
      if len(nomes) > 1:
        raise self.erro('só é possível dar um valor inicial quando a linha declara uma única variável')
      self.expect_token(TokenEnum.ATR)
      inicio = self.pos
      self.grammar_expression()
      linha['expressao'] = (inicio, self.pos)
    return linha

  def grammar_tipo(self) -> dict:
    # tipo simples | lista de T | vetor[N] de T
    tipo = self.current_lexeme()
    descricao = {'tipo': tipo, 'elemento': None, 'tamanho': None}
    if self.check_token(TokenEnum.ID) and tipo == 'vetor':
      self.expect_token(TokenEnum.ID)
      self.expect_token(TokenEnum.COLCHETEA)
      tamanho = self.current_lexeme()
      if not (self.check_token(TokenEnum.NUMINT) and tamanho.isdigit() and int(tamanho) > 0):
        raise self.erro('o tamanho do vetor precisa ser um número inteiro maior que zero, como vetor[5] de inteiro')
      self.expect_token(TokenEnum.NUMINT)
      self.expect_token(TokenEnum.COLCHETEF)
      self.expect_token(TokenEnum.DE)
      descricao['tamanho'] = int(tamanho)
      descricao['elemento'] = self.grammar_tipo_elemento()
    elif self.check_token(TokenEnum.ID) and tipo == 'lista' and self.peek_next_token() == TokenEnum.DE.name:
      self.expect_token(TokenEnum.ID)
      self.expect_token(TokenEnum.DE)
      descricao['elemento'] = self.grammar_tipo_elemento()
    elif self.check_token(TokenEnum.ID) and tipo in TIPOS_CONTEXTUAIS:
      self.expect_token(TokenEnum.ID)
    else:
      self.expect_token(TokenEnum.TIPO)
      # O lexer aceita tipos em qualquer caixa (INTEIRO, Real); o resto do compilador usa a forma minuscula
      descricao['tipo'] = tipo.lower()
    return descricao

  def grammar_tipo_elemento(self) -> str:
    elemento = self.current_lexeme()
    if not (self.check_token_any([TokenEnum.TIPO, TokenEnum.ID]) and elemento.lower() in TIPOS_ELEMENTO):
      raise self.erro('o tipo dos elementos precisa ser inteiro, real, float, cadeia, string ou logico')
    self.pos += 1
    return elemento.lower()

  def grammar_command_escreva(self):
    self.expect_token(TokenEnum.ESCREVA)
    self.grammar_arguments(TokenEnum.PARAB, TokenEnum.PARFE)

  def grammar_command_leia(self):
    self.expect_token(TokenEnum.LEIA)
    self.expect_token(TokenEnum.PARAB)

    if self.check_token(TokenEnum.ID):
      self.expect_token(TokenEnum.ID)
    else:
      raise self.erro(f'o comando leia precisa de uma variável, encontrado {self.descrever_atual()}')

    self.expect_token(TokenEnum.PARFE)
  
  def grammar_command_se(self):
    self.expect_token(TokenEnum.SE)
    self.grammar_expression()

    self.expect_token(TokenEnum.ENTAO)
    self.block_statements([TokenEnum.SENAO, TokenEnum.FIMSE])
    
    if self.check_token(TokenEnum.SENAO):
      self.expect_token(TokenEnum.SENAO)
      self.block_statements([TokenEnum.FIMSE])

    self.expect_token(TokenEnum.FIMSE)

  def grammar_command_enquanto(self):
    self.expect_token(TokenEnum.ENQUANTO)
    self.grammar_expression()
    
    if self.check_token(TokenEnum.FACA):
        self.expect_token(TokenEnum.FACA)
    
    self.block_statements([TokenEnum.FIMENQUANTO])

    self.expect_token(TokenEnum.FIMENQUANTO)

  def grammar_command_para(self):
    self.expect_token(TokenEnum.PARA)
    self.expect_token(TokenEnum.ID)
    
    self.expect_token(TokenEnum.DE)
    self.grammar_expression()
    
    self.expect_token(TokenEnum.ATE)
    self.grammar_expression() 
    
    if self.check_token(TokenEnum.PASSO):
      self.expect_token(TokenEnum.PASSO)
      self.grammar_expression() 

    if self.check_token(TokenEnum.FACA):
        self.expect_token(TokenEnum.FACA)

    self.block_statements([TokenEnum.FIMPARA])

    self.expect_token(TokenEnum.FIMPARA)

  #
  # Expressoes (do menor para o maior nivel de precedencia)
  #   expressao  := ou
  #   ou         := e ("ou" e)*
  #   e          := nao ("e" nao)*
  #   nao        := "nao" nao | relacional
  #   relacional := aditiva (op_relacional aditiva)?
  #   aditiva    := mult (("+" | "-") mult)*
  #   mult       := unario (("*" | "/" | "%" | "mod") unario)*
  #   unario     := "-" unario | primario
  #
  RELACIONAIS = [
    TokenEnum.LOGIGUAL, TokenEnum.LOGDIFF,
    TokenEnum.LOGMENOR, TokenEnum.LOGMENORIGUAL,
    TokenEnum.LOGMAIOR, TokenEnum.LOGMAIORIGUAL
  ]

  def grammar_expression(self):
    self.grammar_ou()

  def grammar_ou(self):
    self.grammar_e()
    while self.check_token(TokenEnum.OU):
      self.expect_token(TokenEnum.OU)
      self.grammar_e()

  def grammar_e(self):
    self.grammar_nao()
    while self.check_token(TokenEnum.E):
      self.expect_token(TokenEnum.E)
      self.grammar_nao()

  def grammar_nao(self):
    if self.check_token(TokenEnum.NAO):
      self.expect_token(TokenEnum.NAO)
      self.grammar_nao()
    else:
      self.grammar_relacional()

  def grammar_relacional(self):
    self.grammar_aditiva()

    if self.check_token_any(self.RELACIONAIS) or self.is_equal_sign():
      self.pos += 1
      self.grammar_aditiva()
    elif self.check_token(TokenEnum.ATR):
      # '<-' nunca aparece dentro de uma expressao
      raise self.erro('"<-" serve para atribuir; para comparar use "=" ou "=="')

  def grammar_aditiva(self):
    self.grammar_mult()
    while self.check_token_any([TokenEnum.OPMAIS, TokenEnum.OPMENOS]):
      self.pos += 1
      self.grammar_mult()

  def grammar_mult(self):
    self.grammar_unario()
    while self.check_token_any([TokenEnum.OPMULTI, TokenEnum.OPDIVI, TokenEnum.OPMOD]):
      self.pos += 1
      self.grammar_unario()

  def grammar_unario(self):
    if self.check_token(TokenEnum.OPMENOS):
      self.expect_token(TokenEnum.OPMENOS)
      self.grammar_unario()
    else:
      self.grammar_primario()

  def grammar_arguments(self, abre: TokenEnum, fecha: TokenEnum):
    # Lista de expressoes separadas por virgula, possivelmente vazia
    self.expect_token(abre)
    if not self.check_token(fecha):
      self.grammar_expression()
      while self.check_token(TokenEnum.COMMA):
        self.expect_token(TokenEnum.COMMA)
        self.grammar_expression()
    self.expect_token(fecha)

  def grammar_cauda(self):
    # Membros, chamadas e indices encadeados: a.b(1)[2].c
    while self.check_token_any([TokenEnum.PONTO, TokenEnum.PARAB, TokenEnum.COLCHETEA]):
      if self.check_token(TokenEnum.PONTO):
        self.expect_token(TokenEnum.PONTO)
        self.expect_token(TokenEnum.ID)
      elif self.check_token(TokenEnum.PARAB):
        self.grammar_arguments(TokenEnum.PARAB, TokenEnum.PARFE)
      else:
        self.expect_token(TokenEnum.COLCHETEA)
        self.grammar_expression()
        self.expect_token(TokenEnum.COLCHETEF)

  def grammar_primario(self):
    if self.check_token(TokenEnum.ID):
      self.expect_token(TokenEnum.ID)
      self.grammar_cauda()

    elif self.check_token(TokenEnum.NOVO):
      self.expect_token(TokenEnum.NOVO)
      
      if self.check_token(TokenEnum.TIPO):
          self.expect_token(TokenEnum.TIPO)
      else:
          self.expect_token(TokenEnum.ID)
          
      self.grammar_arguments(TokenEnum.PARAB, TokenEnum.PARFE)

    elif self.is_chamada_fila_prioridade():
      self.expect_token(TokenEnum.TIPO)
      self.grammar_arguments(TokenEnum.PARAB, TokenEnum.PARFE)
      self.grammar_cauda()

    elif self.check_token(TokenEnum.NUMINT):
      self.expect_token(TokenEnum.NUMINT)
    elif self.check_token(TokenEnum.STRING):
      self.expect_token(TokenEnum.STRING)
    elif self.check_token(TokenEnum.COLCHETEA):
      self.grammar_arguments(TokenEnum.COLCHETEA, TokenEnum.COLCHETEF)
      self.grammar_cauda()

    elif self.check_token(TokenEnum.CHAVEA):
      self.expect_token(TokenEnum.CHAVEA)
      
      if not self.check_token(TokenEnum.CHAVEF):
          self.grammar_expression() # Chave
          self.expect_token(TokenEnum.COLON)   # :
          self.grammar_expression() # Valor
          
          while self.check_token(TokenEnum.COMMA):
              self.expect_token(TokenEnum.COMMA)   # ,
              self.grammar_expression() # Chave
              self.expect_token(TokenEnum.COLON)   # :
              self.grammar_expression() # Valor
              
      self.expect_token(TokenEnum.CHAVEF)

    elif self.check_token(TokenEnum.PARAB):
      self.expect_token(TokenEnum.PARAB)
      self.grammar_expression()
      self.expect_token(TokenEnum.PARFE)
      self.grammar_cauda()
    else:
      raise self.erro(f'esperado um valor ou expressão, encontrado {self.descrever_atual()}')

  def grammar_function_declaration(self):
    self.expect_token(TokenEnum.FUNCAO)
    self.expect_token(TokenEnum.ID)     
    self.expect_token(TokenEnum.PARAB)  # (
    
    if self.check_token(TokenEnum.ID):
      self.expect_token(TokenEnum.ID)
      while self.check_token(TokenEnum.COMMA):
        self.expect_token(TokenEnum.COMMA)
        self.expect_token(TokenEnum.ID)
        
    self.expect_token(TokenEnum.PARFE)  # )
    
    while not self.check_token(TokenEnum.FIMFUNCAO):
      self.statement()
      
    self.expect_token(TokenEnum.FIMFUNCAO)

  def grammar_command_retorne(self):
    self.expect_token(TokenEnum.RETORNE)
    self.grammar_expression() # O que ele vai retornar
  
  def grammar_class_declaration(self):
    self.expect_token(TokenEnum.CLASSE)
    self.expect_token(TokenEnum.ID) # Nome da classe
    while self.check_token(TokenEnum.METODO):
      self.grammar_method_declaration()

    self.expect_token(TokenEnum.FIMCLASSE)

  def grammar_method_declaration(self):
    self.expect_token(TokenEnum.METODO)
    self.expect_token(TokenEnum.ID)     # Nome do método
    self.expect_token(TokenEnum.PARAB)  # (
    
    if self.check_token(TokenEnum.ID):
      self.expect_token(TokenEnum.ID)
      while self.check_token(TokenEnum.COMMA):
        self.expect_token(TokenEnum.COMMA)
        self.expect_token(TokenEnum.ID)
        
    self.expect_token(TokenEnum.PARFE)  # )
    
    while not self.check_token(TokenEnum.FIMFUNCAO):
      self.statement()
      
    self.expect_token(TokenEnum.FIMFUNCAO)